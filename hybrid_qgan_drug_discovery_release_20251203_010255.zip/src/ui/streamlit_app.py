"""Main Streamlit application for Hybrid Quantum GAN Drug Discovery."""
import streamlit as st
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent.parent))

from src.utils import get_config

# Page config
st.set_page_config(
    page_title="HQ-GAN Drug Discovery",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
    <style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #1B1F24;
        padding: 1.5rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        border: 1px solid #2A2F36;
    }
    .metric-label {
        font-size: 0.9rem;
        color: #9aa4ad;
        margin-bottom: 0.2rem;
    }
    .metric-value {
        font-size: 1.8rem;
        font-weight: 600;
        color: #e6edf3;
    }
    .section-divider {
        border-top: 1px solid #2A2F36;
        margin: 1.5rem 0;
    }
    </style>
""", unsafe_allow_html=True)

def main():
    """Main application."""
    # Header
    st.markdown('<div class="main-header">🧬 Hybrid Quantum GAN Drug Discovery</div>', unsafe_allow_html=True)
    
    # Sidebar
    st.sidebar.title("Navigation")
    st.sidebar.info("""
    **Welcome to HQ-GAN Drug Discovery!**
    
    This platform combines:
    - 🔬 Hybrid Quantum GANs
    - 💊 Molecular Generation
    - 🎯 QSAR Prediction
    - ☠️ Toxicity Assessment
    - 🔗 Molecular Docking
    - 📊 Explainability (SHAP)
    """)
    
    # Main content
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.markdown('<div class="metric-label">Molecules Generated</div>', unsafe_allow_html=True)
        st.markdown('<div class="metric-value">1,234</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.markdown('<div class="metric-label">Avg. QED Score</div>', unsafe_allow_html=True)
        st.markdown('<div class="metric-value">0.78</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col3:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.markdown('<div class="metric-label">Drug-like Candidates</div>', unsafe_allow_html=True)
        st.markdown('<div class="metric-value">892</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)
    
    # Quick start guide
    st.header("🚀 Quick Start")
    
    tab1, tab2, tab3 = st.tabs(["📖 Overview", "⚡ Generate", "📊 Analyze"])
    
    with tab1:
        st.markdown("""
        ### Project Overview
        
        This platform implements a **Hybrid Quantum GAN** system for drug discovery:
        
        1. **Molecular Generation**: Generate novel drug-like molecules using quantum-enhanced GANs
        2. **Property Prediction**: Predict QSAR, toxicity, and ADMET properties
        3. **Docking Simulation**: Evaluate binding affinity to target proteins
        4. **Explainability**: Understand predictions with SHAP analysis
        5. **Reporting**: Generate comprehensive PDF reports
        
        **Navigate using the pages in the sidebar →**
        """)
        
        st.info("💡 **Tip**: Start by generating molecules in the 'Generate Molecules' page!")
    
    with tab2:
        st.markdown("### Quick Generate")
        num_molecules = st.slider("Number of molecules", 1, 50, 10)
        
        if st.button("Generate Molecules", type="primary"):
            with st.spinner("Generating molecules..."):
                st.success(f"✓ Generated {num_molecules} molecules!")
                st.info("View them in the 'Generate Molecules' page")
    
    with tab3:
        st.markdown("### Recent Activity")
        st.line_chart({"Generations": [10, 15, 12, 20, 18, 25, 22]})
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: gray;'>
        <p>Hybrid Quantum GAN Drug Discovery System | Version 1.0.0</p>
        <p>Built with Streamlit, PyTorch, PennyLane, RDKit & DeepChem</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
